
//

import UIKit

// MARK: - UISearchBar
extension UISearchBar {
    func enableSearchCancelButton(searchBar: UISearchBar) {
        for view in searchBar.subviews {
            for subview in view.subviews {
                if let button = subview as? UIButton {
                    button.isEnabled = true
                }
            }
        }
    }
}

// MARK: - Int
extension Int {
    var quantityFormat: String {
        return String(format: "%02d", self)
    }
}

// MARK: - String
extension String {
    func dateFor(format: String) -> Date? {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = format
        let date = dateFormatter.date(from: self)
        return date
    }
    
    func sha256Encryption() -> String? {
        let data = self.data(using: String.Encoding.utf8)
        let res = NSMutableData(length: Int(CC_SHA256_DIGEST_LENGTH))
        CC_SHA256(((data! as NSData)).bytes, CC_LONG(data!.count), res?.mutableBytes.assumingMemoryBound(to: UInt8.self))
        let hashedString = "\(res!)".replacingOccurrences(of: "", with: "").replacingOccurrences(of: " ", with: "")
        let badchar: CharacterSet = CharacterSet(charactersIn: "\"<\",\">\"")
        let cleanedstring: String = (hashedString.components(separatedBy: badchar) as NSArray).componentsJoined(by: "")
        return cleanedstring
    }

    
    func convertDate(fromFormat: String, toFormat: String) -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = fromFormat
        if let dateTimeObj = dateFormatter.date(from: self) {
            dateFormatter.dateFormat = toFormat
            let outputDate = "\(dateFormatter.string(from: dateTimeObj))"
            return outputDate
        } else {
            return "Date: N/A"
        }
    }
}

// MARK: - NSDictionary
extension NSDictionary {
    func stringFromHttpParameters() -> String {
        var parametersString = ""
        for (key, value) in self {
            if let key = key as? String,
                let value = value as? String {
                parametersString += key + "=" + value + "&"
            }
        }
        parametersString = parametersString.substring(to: parametersString.index(before: parametersString.endIndex))
        return parametersString.addingPercentEncoding(withAllowedCharacters: .urlHostAllowed)!
    }
}

// MARK: - Array + UITextField
extension Array {
    func resignAllTextfields(arrTxtFields: [UITextField]) {
        arrTxtFields.forEach { $0.resignFirstResponder()
        }
    }
    
    func emptyAllTextfields() {
        self.forEach { if let txt = $0 as? UITextField {
            txt.text = ""
            }
        }
    }
}

// MARK: - Date
extension Date {
    func stringFor(format: String) -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = format
        let strDate = dateFormatter.string(from: self)
        return strDate
    }
}

// MARK: - UITextField
extension UITextField {
    func requiredFieldIndicatior() {
        guard let placeHolderText = self.placeholder, placeHolderText.characters.last == "*" else {
            return
        }
        let myMutableString = NSMutableAttributedString(
            string: placeHolderText,
            attributes: nil)
        myMutableString.addAttribute(
            NSForegroundColorAttributeName,
            value: UIColor.red,
            range: NSRange(location:placeHolderText.characters.count-1, length:1))
        self.attributedPlaceholder = myMutableString
    }
}

// MARK: - UILabel
extension UILabel {
    func requiredFieldIndicatior() {
        
        self.text?.characters.append("*")
        let myMutableString = NSMutableAttributedString(
            string: self.text!,
            attributes: nil)
        myMutableString.addAttribute(
            NSForegroundColorAttributeName,
            value: UIColor.red,
            range: NSRange(location:(self.text?.characters.count)!-1, length:1))
        self.attributedText = myMutableString
    }
}
