//
//  AppDelegate.swift
//  DemoProject
//
//  Created by alpesh patel on 4/18/17.
//  Copyright © 2017 alpesh patel. All rights reserved.
//

import UIKit
import CoreData
import Fabric
import TwitterKit
import Crashlytics
import IQKeyboardManagerSwift
import UserNotifications

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    
   // MARK: Variables
    var window: UIWindow?

      // MARK: Life Cycle Methods
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        
        
        //IQKeyboard
        IQKeyboardManager.sharedManager().enable = true
        
        //Register device
       // registerforRemoteNotification(application)
        
        // Initialize Twitter
        Fabric.with([Twitter.self, Crashlytics.self])
        
        // Setup appearances of Controls
        setupAppearances()
        
        //Get Current Location
        Shared.sharedInstance.getCurrentLocation()

        return true
    }

    func applicationWillResignActive(_ application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    }

    func applicationWillEnterForeground(_ application: UIApplication) {
        // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
    }

    func applicationDidBecomeActive(_ application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    }

    func applicationWillTerminate(_ application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
        // Saves changes in the application's managed object context before the application terminates.
        self.saveContext()
    }

    // MARK: - DidReceiveRemoteNotificationIOS9/8
    func application(_ application: UIApplication, didReceiveRemoteNotification userInfo: [AnyHashable: Any]) {
        print(userInfo)
        handleNotification(userInfo: userInfo as NSDictionary, state: UIApplication.shared.applicationState)
    }
    
    @available(iOS 10.0, *)
    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {
        let userInfo =  response.notification.request.content.userInfo
        handleNotification(userInfo: userInfo as NSDictionary, state: UIApplication.shared.applicationState)
    }
    
    @available(iOS 10.0, *)
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        completionHandler(UNNotificationPresentationOptions.alert)
    }
    
    // MARK: - Register Remotenotifications
    func registerforRemoteNotification(_ application: UIApplication) {
        if #available(iOS 10.0, *) {
            UNUserNotificationCenter.current().delegate = self as! UNUserNotificationCenterDelegate
            UNUserNotificationCenter.current().requestAuthorization(options: [.badge, .sound, .alert], completionHandler: { (granted, error) in
                if error == nil {
                    if granted {
                        UIApplication.shared.registerForRemoteNotifications()
                    }
                }
            })
        } else {
            let settings = UIUserNotificationSettings(types: [.alert, .badge, .sound], categories: nil)
            application.registerUserNotificationSettings(settings)
            application.registerForRemoteNotifications()
        }
    }
    
    func extractTokenFromData(deviceToken: Data) -> String {
        let token = deviceToken.reduce("", {$0 + String(format: "%02X", $1)})
        return token.uppercased()
    }
    
    // MARK: - Set Application Appearance
    func setupAppearances() {
        //UINavigationBar
        let colorOne = UIColor.init(red: 90/250, green: 193/250, blue: 161/250, alpha: 1.0)
        let colorTwo = UIColor.init(red: 52/250, green: 153/250, blue: 122/250, alpha: 1.0)
        let gradientLayerView: UIView = UIView(frame: CGRect(x: 0, y: -20, width: UIScreen.main.bounds.width, height: 64))
        let gradient: CAGradientLayer = CAGradientLayer()
        gradient.frame = gradientLayerView.bounds
        gradient.colors = [colorTwo.cgColor, colorOne.cgColor]
        gradientLayerView.layer.insertSublayer(gradient, at: 0)
        UIGraphicsBeginImageContext(gradient.bounds.size)
        gradient.render(in: UIGraphicsGetCurrentContext()!)
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        if let navigationController: UINavigationController = window?.rootViewController as? UINavigationController {
            navigationController.navigationBar.setBackgroundImage(image, for: UIBarMetrics.default)
            UINavigationBar.appearance().tintColor = UIColor.white
            UINavigationBar.appearance().barTintColor = UIColor(colorLiteralRed: 90/255.0, green: 193/255.0, blue: 161/255.0, alpha: 1.0)
            UINavigationBar.appearance().isTranslucent = false
            let titleAttributes = [
                NSForegroundColorAttributeName: UIColor.white.withAlphaComponent(1.0),
                NSFontAttributeName: UIFont(name: "PlayfairDisplay-Italic", size: 18.0)!
            ]
            UINavigationBar.appearance().titleTextAttributes = titleAttributes
            //UIBarButtonItem
            //  UIBarButtonItem.appearance().tintColor = UIColor.white
            let barButtonAttributes = [
                NSFontAttributeName: UIFont(name: "MuseoSans-500", size: 17)!
            ]
            UIBarButtonItem.appearance().setTitleTextAttributes(barButtonAttributes, for: .normal)
            UIBarButtonItem.appearance().setTitleTextAttributes(barButtonAttributes, for: .highlighted)
            UIBarButtonItem.appearance().setTitleTextAttributes(barButtonAttributes, for: .selected)
        }
    }
    
    // MARK: - Handle Notification
    func handleNotification(userInfo: NSDictionary, state: UIApplicationState) {
        
        if let info = userInfo["aps"] as? NSDictionary {
            if let dataInfo =  info["data"] as? NSDictionary {
                if let notifType = dataInfo["type"] as? String {
                    if notifType == "orderplaced" {
                        if let alertInfo = info["alert"] as? NSDictionary {
                        let count = alertInfo["badge"] as? Int ?? 0
                    Shared.sharedInstance.userDetailObj?.countNotification = count
                            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "UpdateNotifcationCount"), object: nil)
                            // let strMessage = alertInfo["body"] as? String ?? ""
                            // CommonMethods.showAlert(strMessage: strMessage, cancelButtonTitle: "OK", otherButtonTitles: nil, customAlertViewTapButtonBlock: nil, isWarning: true)
                        }
                    }
                }
            }
            
        }
    }
    // MARK: - Core Data stack

    lazy var persistentContainer: NSPersistentContainer = {
        /*
         The persistent container for the application. This implementation
         creates and returns a container, having loaded the store for the
         application to it. This property is optional since there are legitimate
         error conditions that could cause the creation of the store to fail.
        */
        let container = NSPersistentContainer(name: "DemoProject")
        container.loadPersistentStores(completionHandler: { (storeDescription, error) in
            if let error = error as NSError? {
                // Replace this implementation with code to handle the error appropriately.
                // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
                 
                /*
                 Typical reasons for an error here include:
                 * The parent directory does not exist, cannot be created, or disallows writing.
                 * The persistent store is not accessible, due to permissions or data protection when the device is locked.
                 * The device is out of space.
                 * The store could not be migrated to the current model version.
                 Check the error message to determine what the actual problem was.
                 */
                fatalError("Unresolved error \(error), \(error.userInfo)")
            }
        })
        return container
    }()

    // MARK: - Core Data Saving support

    func saveContext () {
        let context = persistentContainer.viewContext
        if context.hasChanges {
            do {
                try context.save()
            } catch {
                // Replace this implementation with code to handle the error appropriately.
                // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
                let nserror = error as NSError
                fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
            }
        }
    }

}

