
//

import UIKit

class Constant: NSObject {
    
    static var googleMaps: String = "AIzaSyBQSJ29wbQfk8D9tbpSB3x-o-LrrwIaYdc"

    static let defaults = UserDefaults.standard
    static var databaseVersion: Int = 1
    static var deviceToken: String = ""
    static var appDelegate = UIApplication.shared.delegate as? AppDelegate
    static let documentsURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
    
    // MARK: - Screen Size
    static var kScreenBounds: CGRect = UIScreen.main.bounds
    static var isiPhone4: Bool = 480 == UIScreen.main.bounds.size.height ? true : false
    static var isiPhone5: Bool = 568 == UIScreen.main.bounds.size.height ? true : false
    static var isiPhone6: Bool = 667 == UIScreen.main.bounds.size.height ? true : false
    static var isiPhone6Plus: Bool = 736 == UIScreen.main.bounds.size.height ? true : false
    
    // MARK: - Storyboard File
    static let productCatalogStoryboard: UIStoryboard = UIStoryboard(name: "ProductCatalog", bundle: nil)
    static let signUpStoryboard: UIStoryboard = UIStoryboard(name: "Signup", bundle: nil)
    static let settingsStoryboard: UIStoryboard = UIStoryboard(name: "Settings", bundle: nil)
    static let checkoutStoryboard: UIStoryboard = UIStoryboard(name: "Checkout", bundle: nil)
}
