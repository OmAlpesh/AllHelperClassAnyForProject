
//

import UIKit

class ThemeVC: UIViewController {
    
    // MARK: - Variables
    let vwBottomMenu: UIView = (Bundle.main.loadNibNamed("BottomMenu", owner: self, options: nil)?.first as? UIView)!
    
    // MARK: - User Actions
    func storeTapped() {
      
    }
    
    func cartTapped() {
      
      }
    
    // MARK: - Life Cycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    // MARK: Methods
    func addBackgroundImage() {
        let imgViewBackground = UIImageView.init(frame: CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: self.view.frame.size.height))
        imgViewBackground.image = #imageLiteral(resourceName: "bgregister")
        self.view.insertSubview(imgViewBackground, at: 0)
    }
    
    func addBottomMenu() {
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 0.1) {
            let bottomMenuFrame: CGRect = CGRect(x: 0.0, y: self.view.frame.size.height - 44.0, width: UIScreen.main.bounds.size.width, height: 44.0)
            self.vwBottomMenu.frame = bottomMenuFrame
            self.vwBottomMenu.layoutSubviews()
            self.view.addSubview(self.vwBottomMenu)
            self.view.bringSubview(toFront: self.vwBottomMenu)
            //add target
            if let btnStore = self.vwBottomMenu.viewWithTag(10) as? UIButton {
                btnStore.addTarget(self, action: #selector(self.storeTapped), for: UIControlEvents.touchUpInside)
            }
            if let btnCart = self.vwBottomMenu.viewWithTag(20) as? UIButton {
                btnCart.addTarget(self, action: #selector(self.cartTapped), for: UIControlEvents.touchUpInside)
            }
            self.showBottomMenuDetails()
        }
    }
    

    // MARK: Assign/Update Values
    func showBottomMenuDetails() {
        
        let lblStoreName: UILabel = (vwBottomMenu.viewWithTag(1) as? UILabel)!
      
        let lblPickupTime: UILabel = (vwBottomMenu.viewWithTag(2) as? UILabel)!
        
        lblStoreName.text = "Alpesh"
        lblPickupTime.text = "Patel"
    }
    
    func navigateToDepartment() {
        let dVC = Constant.productCatalogStoryboard.instantiateViewController(withIdentifier: "DepartmentVC")
        if let navigationController: UINavigationController = UIApplication.shared.keyWindow!.rootViewController as? UINavigationController {
            navigationController.viewControllers = [dVC]
        }
    }
    
    func setMarqueeTitle(title: String) {
        let marqueeLabel = MarqueeLabel(frame: CGRect.init(x: 0, y: 0, width: 320, height: 25), duration: 7.0, fadeLength: 20.0)
        marqueeLabel.font = UIFont(name: "PlayfairDisplay-Italic", size: 18.0)
        marqueeLabel.textColor = UIColor.white
        marqueeLabel.trailingBuffer = 30.0
        marqueeLabel.text = title
        marqueeLabel.textAlignment = .center
        self.navigationItem.titleView = marqueeLabel
    }
}
