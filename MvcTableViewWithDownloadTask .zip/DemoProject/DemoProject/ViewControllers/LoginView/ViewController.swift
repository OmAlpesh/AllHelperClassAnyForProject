//
//  ViewController.swift
//  DemoProject
//
//  Created by alpesh patel on 4/18/17.
//  Copyright © 2017 alpesh patel. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    //MARK: IBOutLat
    
    @IBOutlet weak var txtUserName: UITextField!
    
    @IBOutlet weak var txtPassword: UITextField!
    
     //MARK: Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK: Action Method
    @IBAction func btnSubmitTapped(_ sender: Any) {
        
        loginWSCall()
    }
    
    // MARK: - WS Call
    func loginWSCall() {
        CommonMethods.showMBProgressHud()
        let wsObj = APIManager()
        wsObj.delegate = self
       
        wsObj.requestForURL(strUrl: APIList.strServerUrl, httpMethod: "Post", parameters: nil, includeHeader: true, apiIdentifier: "login")
    }

    
//    func loginWSCall(emailId stremail: String, password strPass: String, type strType: String, tId strTid: String) {
//        CommonMethods.showMBProgressHud()
//        let wsObj = APIManager()
//        wsObj.delegate = self
//        let para = ["email": stremail, "password": strPass.sha256Encryption()!, "type_id": strTid, "type": strType, "notification_token": Shared.sharedInstance.strDeviceToken]
//        wsObj.requestForURL(strUrl: APIList.strLoginUrl, httpMethod: "Post", parameters: para as NSDictionary?, includeHeader: true, apiIdentifier: "login")
//    }

}

// MARK: - API Methods
extension ViewController: APIManagerDelegate {
    func apiResponseSuccess(response: NSDictionary, apiIdentifier: String) {
        CommonMethods.hideMBProgressHud()
        
        if apiIdentifier == "login" {
            
           //  print(response)
            let userObj = UserDetails.init(fromDictionary: response)
            Shared.sharedInstance.userDetailObj = userObj
          
            
            //Save To Defaults
            let userDefaults = UserDefaults.standard
            let encodedData: Data = NSKeyedArchiver.archivedData(withRootObject: userObj)
            userDefaults.set(encodedData, forKey: "userdetail")
            userDefaults.synchronize()
            UserDefaults.standard.setValue(txtUserName.text, forKey: "regEmail")
        }
    }
    
    func apiResponseFail(response: NSDictionary, apiIdentifier: String) {
        CommonMethods.hideMBProgressHud()
        print(response)
        
        let userList = response.value(forKey: "data") as? [[String:Any]]
        print(userList as Any)
        
        if let userArray = userList {
              //print(userArray)
            
            if let DownLoadView = Constant.MainStoryBoard.instantiateViewController(withIdentifier: "DownLoadView") as? DownLoadView {
                
                for user in userArray {
                    //  print(user)
                    let userObj = UserDetails.init(fromDictionary: user as NSDictionary)
                    DownLoadView.arrUserList.append(userObj)
                    print(userObj)
                     print(DownLoadView.arrUserList)
                }

              
                CommonMethods.navigateTo(DownLoadView, inNavigationViewController: self.navigationController!, animated: true)
            }
        }
    }
    
    func apiResponseError(error: Error?, apiIdentifier: String) {
        CommonMethods.hideMBProgressHud()
        if apiIdentifier == "login" {
            
        }
    }
}

