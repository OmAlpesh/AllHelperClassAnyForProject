//
//  DownloadCellTableViewCell.swift
//  DemoProject
//
//  Created by alpesh patel on 4/19/17.
//  Copyright © 2017 alpesh patel. All rights reserved.
//

import UIKit


@objc protocol DownLoadCellDelegate : class {

    @objc optional func btnDownLoadTapped(_ cell: DownloadCellTableViewCell)
}


class DownloadCellTableViewCell: UITableViewCell {

    var delegate: DownLoadCellDelegate?
    
    @IBOutlet weak var btnDownLoad: UIButton!
    
    @IBOutlet weak var lblUserName: UILabel!
    
    @IBOutlet weak var lblUrlName: UILabel!
    
    @IBOutlet weak var prProgrssView: UIProgressView!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func configureCell(userData: UserDetails) {
      
        lblUrlName.text = userData.strImage
        lblUserName.text = userData.strUserName
    }

    
    @IBAction func btnDownLoadTapped(_ sender: AnyObject) {
        delegate?.btnDownLoadTapped!(self)
    }

}
