
//

import UIKit

class UserDetails: NSObject {
    
    var strUserName: String?
    var strEmailId: String?
    var strImage: String?
    var strLat: String?
    var strLong: String?
    
    
   init(fromDictionary dataData: NSDictionary) {
    
    
        strUserName =  dataData["username"] as? String ?? ""
        strEmailId = dataData["email"] as? String ?? ""
        strImage = dataData["image"] as? String ?? ""
        strLat = dataData["lat"] as? String ?? ""
        strLong = dataData["long"] as? String
    
//        if let dataData = dictionary["data"] as? NSDictionary {
//            strUserName =  dataData["username"] as? String ?? ""
//            strEmailId = dataData["email"] as? String ?? ""
//            strImage = dataData["image"] as? String ?? ""
//            strLat = dataData["lat"] as? String ?? ""
//            strLong = dataData["long"] as? String
//        }
    }
    
}
