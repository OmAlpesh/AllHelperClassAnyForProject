
//

import UIKit

class APIList: NSObject {
    
    static let strVersion = "v1"
    //static let strServerUrl = "https://ngcfo.ossclients.com/api/rest/" + strVersion + "/"
    //QA URL
  //  static let strServerUrl = "http://cfoapiqa.ossclients.com/api/rest/" + strVersion + "/"
    
    static let strServerUrl = "http://192.168.1.50/zap/backend/web/index.php/webservice/clientdata"
    
    //UAT Url
    //static let strServerUrl = "https://prontotogouat.northgatemarkets.com/cfoapi/api/rest/" + strVersion + "/"
    
    //Splash
    static let strSplashUrl = "splash"
    
    //Tutorial
    static let strTutorialUrl = "tutorial"
    
    //Login
    static let strLoginUrl = "login"
    
    //Forgot
    static let strForgotUrl = "forgotpassword"
    
    //Signup
    static let strSignupUrl = "register"
    static let strStateUrl = "states"
    static let strCountryUrl = "country"
    
    //Privacy
    static let strPrivacyUrl = "contentpage/privacy"
    
    //Store List
    static let strStoreListUrl = "stores"
    
    //Cart APIs
    static let strGetCartUrl = "addcart"
    static let strAddToCartUrl = "addcart"
    static let strEmptyCartUrl = "cartempty"
    static let strSaveCartUrl = "savedcart"
    static let strUpdateCartUrl = "addcart/1"

    //Checkout APIs
    static let strCheckoutUrl = "restcheckout"
    
    //Category List
    static let strCategoryListUrl = "getcategory"
    
    //Notification List
    static let strNotificationListUrl = "getnotification"

    //Item List
    static let strItemListUrl = "getproducts"

    //Item Details
    static let strItemDetailUrl = "getproductdetails"
    
    //Settings
    static let strGetSettingUrl = "settings"
    static let strUpdateSettingUrl = "settings/update"

    // Profile
    static let strGetProfileUrl = "profile"
    static let strUpdateProfileUrl = "profile/update"
    static let strChangePassUrl = "changepassword"
    static let strGetMobileNumber = "profile/getmobile"
    static let strUpdateMobileNumber = "profile/mobileupdate"
    
    //Rate Product
    static let strRateProductUrl = "rateproduct"
    
    //My Order
    static let strMyOrderListUrl = "myorders"
    static let strSavedCartListUrl = "savedcart"
    
    // Order Review
    static let strOrderReviewUrl = "orderreview"
    
    // Order Confirmation
    static let strOrderConfirmationUrl = "orderconfirm"
    static let strDownloadPdfUrl = "orderpdf"
    
    // Order Payment
    static let strPartialPaymentUrl = "paymenttypecalculation"
    
    // create order
    static let strCreateOrderUrl = "order"
    
    // Logout
    static let strLogoutUrl = "logout"
    
    // Payment Method List
    static let strPaymentMethodList = "paymentmethodlist"
    static let strPaymentDetailCheck = "paymentform/"
}
