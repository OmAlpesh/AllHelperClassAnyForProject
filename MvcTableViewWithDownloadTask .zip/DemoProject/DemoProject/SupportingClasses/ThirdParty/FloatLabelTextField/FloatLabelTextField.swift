//
//  FloatLabelTextField.swift
//  FloatLabelFields
//
//  Created by Fahim Farook on 28/11/14.
//  Copyright (c) 2014 RookSoft Ltd. All rights reserved.
//
//  Original Concept by Matt D. Smith
//  http://dribbble.com/shots/1254439--GIF-Mobile-Form-Interaction?list=users
//
//  Objective-C version by Jared Verdi
//  https://github.com/jverdi/JVFloatLabeledTextField
//

import UIKit

@IBDesignable class FloatLabelTextField: UITextField {
	let animationDuration = 0.3
    
	fileprivate let title = UILabel()
    fileprivate let bottomLine = UIView()
	
	// MARK: - Properties
	override var accessibilityLabel: String? {
		get {
			if let txt = text, txt.isEmpty {
				return title.text
			} else {
				return text
			}
		}
		set {
			self.accessibilityLabel = newValue
		}
	}
	
	override var placeholder: String? {
		didSet {
			title.text = placeholder
		}
	}
	
	override var attributedPlaceholder: NSAttributedString? {
		didSet {
			title.text = attributedPlaceholder?.string
		}
	}
	
	@IBInspectable var hintYPadding: CGFloat = 0.0

	@IBInspectable var titleYPadding: CGFloat = 0.0 {
		didSet {
			var r = title.frame
			r.origin.y = titleYPadding
			title.frame = r
		}
	}

    var placeholderFont: UIFont! {
        didSet {
            //title.font = placeholderFont
        }
    }
    
	@IBInspectable
    var placeholderColour: UIColor = UIColor.gray {
		didSet {
			if !isFirstResponder {
				title.textColor = placeholderColour
                self.setValue(placeholderColour, forKeyPath: "_placeholderLabel.textColor")
			}
		}
	}
	
	@IBInspectable
    var placeholderActiveColour: UIColor! {
		didSet {
			if isFirstResponder {
				title.textColor = placeholderActiveColour
			}
		}
	}
    
    @IBInspectable
    var bottomLineColour: UIColor = UIColor.gray {
        didSet {
            if !isFirstResponder {
                bottomLine.backgroundColor = bottomLineColour
            }
        }
    }
    
    @IBInspectable
    var bottomLineActiveColour: UIColor! {
        didSet {
            if isFirstResponder {
                bottomLine.backgroundColor = bottomLineActiveColour
            }
        }
    }
    
	// MARK: - Init
	required init?(coder aDecoder: NSCoder) {
		super.init(coder:aDecoder)
		setup()
	}
	
	override init(frame: CGRect) {
		super.init(frame:frame)
		setup()
	}
    
	// MARK: - Overrides
	override func layoutSubviews() {
		super.layoutSubviews()
		setTitlePositionForTextAlignment()
		let isResp = isFirstResponder
		if let txt = text, !txt.isEmpty && isResp {
			title.textColor = placeholderActiveColour
            bottomLine.backgroundColor = bottomLineActiveColour
		} else {
			title.textColor = placeholderColour
            bottomLine.backgroundColor = bottomLineColour
		}
		// Should we show or hide the title label?
		if let txt = text, txt.isEmpty {
			// Hide
			hideTitle(isResp)
		} else {
			// Show
			showTitle(isResp)
		}
	}
	
	override func textRect(forBounds bounds: CGRect) -> CGRect {
		var r = super.textRect(forBounds: bounds)
		if let txt = text, !txt.isEmpty {
			var top = ceil(title.font.lineHeight + hintYPadding)
			top = min(top, maxTopInset())
			r = UIEdgeInsetsInsetRect(r, UIEdgeInsets(top: top, left: 0.0, bottom: 0.0, right: 0.0))
		}
		return r.integral
	}
	
	override func editingRect(forBounds bounds: CGRect) -> CGRect {
		var r = super.editingRect(forBounds: bounds)
		if let txt = text, !txt.isEmpty {
			var top = ceil(title.font.lineHeight + hintYPadding)
			top = min(top, maxTopInset())
			r = UIEdgeInsetsInsetRect(r, UIEdgeInsets(top: top, left: 0.0, bottom: 0.0, right: 0.0))
		}
		return r.integral
	}
	
	override func clearButtonRect(forBounds bounds: CGRect) -> CGRect {
		var r = super.clearButtonRect(forBounds: bounds)
		if let txt = text, !txt.isEmpty {
			var top = ceil(title.font.lineHeight + hintYPadding)
			top = min(top, maxTopInset())
			r = CGRect(x:r.origin.x, y:r.origin.y + (top * 0.5), width:r.size.width, height:r.size.height)
		}
		return r.integral
	}
    
	// MARK: - Private Methods
	fileprivate func setup() {
		borderStyle = UITextBorderStyle.none
		// Set up title label
        title.font = self.font
		title.alpha = 0.0
		title.textColor = placeholderColour
        title.textAlignment = self.textAlignment
		if let str = placeholder, !str.isEmpty {
			title.text = str
            title.sizeToFit()
		}
        bottomLine.backgroundColor = bottomLineColour
        self.addSubview(bottomLine)
		self.addSubview(title)
	}

	fileprivate func maxTopInset() -> CGFloat {
		if let fnt = font {
			return max(0, floor(bounds.size.height - fnt.lineHeight - 4.0))
		}
		return 0
	}
	
	fileprivate func setTitlePositionForTextAlignment() {
        title.frame = CGRect(x:0, y:title.frame.origin.y, width:self.bounds.size.width, height:title.frame.size.height)

        var frame: CGRect = self.bounds
        frame.origin.x = 0
        frame.origin.y = self.bounds.size.height - 1.0
        frame.size.height = 1.0
        bottomLine.frame = frame
	}
	
	fileprivate func showTitle(_ animated: Bool) {
		let dur = animated ? animationDuration : 0
		UIView.animate(withDuration: dur, delay:0, options: [UIViewAnimationOptions.beginFromCurrentState, UIViewAnimationOptions.curveEaseOut], animations: {
				// Animation
				self.title.alpha = 1.0
				var r = self.title.frame
				r.origin.y = self.titleYPadding
				self.title.frame = r
			}, completion:nil)
	}
	
	fileprivate func hideTitle(_ animated: Bool) {
		let dur = animated ? animationDuration : 0
		UIView.animate(withDuration: dur, delay:0, options: [UIViewAnimationOptions.beginFromCurrentState, UIViewAnimationOptions.curveEaseIn], animations: {
			// Animation
			self.title.alpha = 0.0
			var r = self.title.frame
			r.origin.y = self.title.font.lineHeight + self.hintYPadding
			self.title.frame = r
			}, completion:nil)
	}
}
