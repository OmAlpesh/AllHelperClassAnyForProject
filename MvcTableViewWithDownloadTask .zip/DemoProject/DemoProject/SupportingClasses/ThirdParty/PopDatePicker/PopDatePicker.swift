import UIKit

@objc protocol PopDatePickerDelegate: NSObjectProtocol {
    func datePickerDidSelectDate(_ date: Date)
}

//DatePicker Mode
public enum DatePickerType {
    case date, time, datetime, countdown
    
    public func dateType() -> UIDatePickerMode {
        switch self {
        case DatePickerType.date: return .date
        case DatePickerType.time: return .time
        case DatePickerType.datetime: return .dateAndTime
        case DatePickerType.countdown: return .countDownTimer
        }
    }
}

open class PopDatePicker: UIView {
    
    //Delegate
    weak var delegate: PopDatePickerDelegate?
    
    //Properties
    fileprivate var containerView: UIView!
    fileprivate var contentView: UIView!
    fileprivate var backgroundView: UIView!
    fileprivate var datePickerView: UIDatePicker!
    
    //Custom Properties
    open var datePickerType: DatePickerType!
    open var localeIdentifier: String = "en_US"
    open var selectButtonTitle: String = "Select"
    open var cancelButtonTitle: String = "Cancel"
    open var buttonFont: UIFont = UIFont.systemFont(ofSize: 16)
    open var selectedDate = Date()
    open var minimumDate: Date?
    
    public init() {
        super.init(frame: CGRect.zero)
        self.backgroundColor = UIColor.clear
    }
    
    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    //Show View
    open func show(attachToView view: UIView) {
        self.show(self, inView: view)
    }
    
    fileprivate func show(_ contentView: UIView, inView: UIView) {
        self.contentView = inView
        self.containerView = UIView()
        self.containerView.frame = CGRect(x: 0, y: 0, width: inView.bounds.width, height: inView.bounds.height)
        self.containerView.backgroundColor = UIColor.init(white: 0.0, alpha: 0.5)
        self.containerView.alpha = 0
        self.contentView.addSubview(self.containerView)
        
        self.backgroundView = createBackgroundView()
        self.containerView.addSubview(self.backgroundView)
        
        self.datePickerView = createDatePicker()
        self.backgroundView.addSubview(self.datePickerView)
        self.backgroundView.addSubview(self.addSelectButton())
        self.backgroundView.addSubview(self.addCancelButton())
        
        //Show UI Views
        UIView.animate(withDuration: 0.05, animations: {
            self.containerView.alpha = 1
        }, completion: { (_) in
            UIView.animate(withDuration: 0.15, delay: 0, options: .transitionCrossDissolve, animations: {
                self.backgroundView.frame.origin.y = self.containerView.bounds.height / 2 - 125
            }, completion: nil)
        })
        let tap = UITapGestureRecognizer(target: self, action: #selector(PopDatePicker.dismiss(_:)))
        self.containerView.addGestureRecognizer(tap)
        
        self.layoutSubviews()
    }
    
    //Handle Tap Dismiss
    func dismiss(_ sender: UITapGestureRecognizer? = nil) {
        UIView.animate(withDuration: 0.15, animations: {
            self.backgroundView.frame.origin.y += self.containerView.bounds.maxY
        }, completion: { (_) in
            UIView.animate(withDuration: 0.05, delay: 0, options: .transitionCrossDissolve, animations: {
                self.containerView.alpha = 0
            }, completion: { (_) in
                self.containerView.removeFromSuperview()
                self.removeFromSuperview()
            })
        })
    }
    
    //Create DatePicker
    fileprivate func createDatePicker() -> UIDatePicker {
        let datePickerView: UIDatePicker = UIDatePicker(frame: CGRect(x: 0, y: 0, width: self.backgroundView.bounds.width, height: self.backgroundView.bounds.height - 50))
        datePickerView.date = self.selectedDate
        if self.minimumDate != nil {
            datePickerView.minimumDate = minimumDate
            datePickerView.maximumDate = Date().addingTimeInterval(365.0 * 24.0 * 60.0 * 60.0)
            if self.minimumDate! > self.selectedDate {
                datePickerView.date = self.minimumDate!
            }
        }
        datePickerView.locale = Locale(identifier: localeIdentifier)
        datePickerView.autoresizingMask = [.flexibleWidth]
        datePickerView.clipsToBounds = true
        datePickerView.backgroundColor = UIColor.white
        datePickerView.datePickerMode = self.datePickerType.dateType()
        return datePickerView
    }
    
    //Create Background Container View
    fileprivate func createBackgroundView() -> UIView {
        let bgView = UIView(frame: CGRect(x: 20, y: self.containerView.bounds.maxY + 100, width: self.contentView.bounds.width - 40, height: 250))
        bgView.autoresizingMask = [.flexibleWidth]
        bgView.backgroundColor = UIColor.red
        bgView.clipsToBounds = true
        return bgView
    }
    
    //Create Select / Cancel Buttons
    fileprivate func addSelectButton() -> UIButton {
        let btnSelect = UIButton(type: .system)
        btnSelect.frame = CGRect(x: self.backgroundView.frame.size.width / 2, y: self.datePickerView.frame.maxY, width: (self.backgroundView.frame.size.width / 2) + 2, height: 51)
        btnSelect.setTitle(selectButtonTitle, for: UIControlState())
        btnSelect.titleLabel?.font = buttonFont
        btnSelect.tintColor = UIColor.black
        btnSelect.backgroundColor = UIColor.white
        btnSelect.layer.borderWidth = 1.0
        btnSelect.layer.borderColor = UIColor(red: 205/255.0, green: 205/255.0, blue: 205/255.0, alpha: 1.0).cgColor
        btnSelect.addTarget(self, action: #selector(PopDatePicker.didSelectDate(_:)), for: .touchUpInside)
        return btnSelect
    }
    
    fileprivate func addCancelButton() -> UIButton {
        let btnSelect = UIButton(type: .system)
        btnSelect.frame = CGRect(x: -1, y: self.datePickerView.frame.maxY, width: (self.backgroundView.frame.size.width / 2) + 2, height: 51)
        btnSelect.setTitle(cancelButtonTitle, for: UIControlState())
        btnSelect.titleLabel?.font = buttonFont
        btnSelect.tintColor = UIColor.black
        btnSelect.backgroundColor = UIColor.white
        btnSelect.layer.borderWidth = 1.0
        btnSelect.layer.borderColor = UIColor(red: 205/255.0, green: 205/255.0, blue: 205/255.0, alpha: 1.0).cgColor
        btnSelect.addTarget(self, action: #selector(PopDatePicker.dismiss(_:)), for: .touchUpInside)
        return btnSelect
    }
    
    //Button Actions
    @objc fileprivate func didSelectDate(_ sender: UIButton) {
        if delegate != nil {
            self.delegate?.datePickerDidSelectDate(self.datePickerView.date)
            self.dismiss()
        }
    }
}
