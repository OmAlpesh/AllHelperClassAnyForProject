
//

import UIKit
import MBProgressHUD

class CommonMethods: NSObject {
    
    // MARK: Variables
    static var hud: MBProgressHUD = MBProgressHUD()
    static var sharedObj: Shared?
    static var navControl: UINavigationController?
    static var isExpandingMenuVisible: Bool = false
    
    // MARK: Navigation Methdods
    
    /**
     This methods manage the navigation.
     
     - parameter destinationVC:        destination view controller
     - parameter navigationController: navigation controller object
     - parameter animated:             Animation (true/false)
     */
    class func navigateTo(_ destinationVC: UIViewController, inNavigationViewController navigationController: UINavigationController, animated: Bool ) {
        //Assign to global value
        navControl = navigationController
        var VCFound: Bool = false
        let viewControllers: NSArray = navigationController.viewControllers as NSArray
        var indexofVC: NSInteger = 0
        for   vc  in navigationController.viewControllers {
            if vc.nibName == (destinationVC.nibName) {
                VCFound = true
                break
            } else {
                indexofVC += 1
            }
        }
        DispatchQueue.main.async(execute: {
            if VCFound == true {
                navigationController .popToViewController((viewControllers.object(at: indexofVC) as? UIViewController)!, animated: animated)
            } else {
                navigationController .pushViewController(destinationVC, animated: animated)
            }
        })
    }
    
    /**
     This methods is used to get reference of already present viewcontroller object.
     
     - parameter destinationVC:        destination view controller
     - parameter navigationController: navigation controller object
     
     - returns: Object of destination view controller
     */
    class func findViewControllerRefInStack(_ destinationVC: UIViewController, inNavigationViewController navigationController: UINavigationController) -> UIViewController {
        var VCFound = false
        var viewControllers = navigationController.viewControllers
        var indexofVC = 0
        for vc: UIViewController in viewControllers {
            if vc.nibName == (destinationVC.nibName) {
                VCFound = true
                break
            } else {
                indexofVC += 1
            }
        }
        if VCFound == true {
            return viewControllers[indexofVC]
        } else {
            return destinationVC
        }
    }
    
    // MARK: Validation Methods
    class func emailAdrressValidation(strEmail: String) -> Bool {
        if strEmail.isEmpty {
            return false
        }
        let emailRegEx = "[.0-9a-zA-Z_-]+@[0-9a-zA-Z.-]+\\.[a-zA-Z]{2,20}"
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        if !emailTest.evaluate(with: strEmail) {
            return false
        }
        return true
    }

    // MARK: Conversion Methods
    class func convertStringToNumber(_ numberString: String) -> Int {
        
        if let number = Int(numberString) {
            return number
        }
        
        return 0
    }
    
    class func convertStringToFloat(_ numberString: String) -> Float {
        
        if let number = Float(numberString) {
            return number
        }
        
        return 0.0
    }
    
    class func convertStringToInt(_ numberString: String) -> Int {
        
        if let number = Int(numberString) {
            return number
        }
        return 0
    }
    
    static func colorWithHexString(_ hex: NSString ) -> UIColor {
        
        let rgbValue = 0xFFEEDD
        let r = CGFloat((rgbValue & 0xFF0000) >> 16)/255.0
        let g = CGFloat((rgbValue & 0xFF00) >> 8)/255.0
        let b = CGFloat((rgbValue & 0xFF))/255.0
        
        return UIColor(red:r, green: g, blue: b, alpha: 1.0)
        
    }
    
    // MARK: HUD Methods
    class func showMBProgressHud() {
        DispatchQueue.main.async(execute: {
            hud = MBProgressHUD.showAdded(to: ((UIApplication.shared.delegate?.window)!)!, animated: true)
            hud.contentColor = UIColor.white
            hud.bezelView.alpha = 1.0
            hud.bezelView.color = UIColor.clear
            hud.bezelView.style = .solidColor
            hud.backgroundView.color = UIColor.black
            hud.backgroundView.alpha = 0.6
            hud.backgroundView.style = .solidColor
        })
    }
    
    class func  hideMBProgressHud() {
        DispatchQueue.main.async(execute: {
            hud.hide(animated: true)
        })
    }
    
    // MARK: Alert Methods
    class func showAlert(strMessage: String, cancelButtonTitle: String, otherButtonTitles: [String]?, customAlertViewTapButtonBlock: ((Int) -> Void)?, isWarning: Bool) {
        if Shared.sharedInstance.movingMenuButton != nil && Shared.sharedInstance.movingMenuButton?.superview != nil {
            CommonMethods.isExpandingMenuVisible = true
            Shared.sharedInstance.hideExpandingMenu()
        }
        var alert: CustomAlertVC?
        if !isWarning {
         alert = CustomAlertVC.init(WithMessage: strMessage, alertIcon: nil, cancelButtonTitle: cancelButtonTitle, otherButtonTitles: otherButtonTitles)
        } else {
            alert = CustomAlertVC.init(WithMessage: strMessage, alertIcon: UIImage(named: "error_alert"), cancelButtonTitle: cancelButtonTitle, otherButtonTitles: otherButtonTitles)
        }
        alert?.buttonDidTappedBlock = { buttonIndex in
            if CommonMethods.isExpandingMenuVisible == true {
                CommonMethods.isExpandingMenuVisible = false
                Shared.sharedInstance.showExpandingMenu()
            }
            if customAlertViewTapButtonBlock != nil {
                customAlertViewTapButtonBlock!(buttonIndex)
            }
        }
        if let navigationController: UINavigationController = UIApplication.shared.keyWindow!.rootViewController as? UINavigationController {
            alert?.modalPresentationStyle = .custom
            alert?.modalTransitionStyle = .crossDissolve
            navigationController.present(alert!, animated: true, completion: nil)
        }
    }

    class func showAlert(strMessage: String, cancelButtonTitle: String, otherButtonTitles: [String]?, customAlertViewTapButtonBlock: ((Int) -> Void)?, isWarning: Bool, navController: UINavigationController) {
        if Shared.sharedInstance.menuButton != nil && Shared.sharedInstance.menuButton?.superview != nil {
            CommonMethods.isExpandingMenuVisible = true
            Shared.sharedInstance.hideExpandingMenu()
        }
        var alert: CustomAlertVC?
        if !isWarning {
            alert = CustomAlertVC.init(WithMessage: strMessage, alertIcon: nil, cancelButtonTitle: cancelButtonTitle, otherButtonTitles: otherButtonTitles)
        } else {
            alert = CustomAlertVC.init(WithMessage: strMessage, alertIcon: UIImage(named: "error_alert"), cancelButtonTitle: cancelButtonTitle, otherButtonTitles: otherButtonTitles)
        }
        alert?.buttonDidTappedBlock = { buttonIndex in
            if CommonMethods.isExpandingMenuVisible == true {
                CommonMethods.isExpandingMenuVisible = false
                Shared.sharedInstance.showExpandingMenu()
            }
            if customAlertViewTapButtonBlock != nil {
                customAlertViewTapButtonBlock!(buttonIndex)
            }
        }
            alert?.modalPresentationStyle = .custom
            alert?.modalTransitionStyle = .crossDissolve
            navController.present(alert!, animated: true, completion: nil)
    }
    /// To apply cournerRadius to any view
    /// - Parameters:
    ///   - sourceView: target View
    ///   - cournerNumber: different switch case where you want to apply cournerRadius like top, bottom,
    ///   - cornorRadius: cornorRadius in CGFloat
    class func roundedCornerForView(_ sourceView: UIView, cournerNumber: CGFloat, cornorRadius: CGFloat) {
        
        if cournerNumber == 10 {
            sourceView.layer.mask?.removeFromSuperlayer()
            return
        }
        
        var maskPath: UIBezierPath = UIBezierPath(roundedRect: sourceView.bounds, byRoundingCorners: ([.bottomLeft, .bottomRight]), cornerRadii: CGSize(width: cornorRadius, height: cornorRadius))
        switch cournerNumber {
        case 1:
            maskPath = UIBezierPath(roundedRect: sourceView.bounds, byRoundingCorners: .topLeft, cornerRadii: CGSize(width: cornorRadius, height: cornorRadius))
        case 2:
            maskPath = UIBezierPath(roundedRect: sourceView.bounds, byRoundingCorners: .topRight, cornerRadii: CGSize(width: cornorRadius, height: cornorRadius))
        case 3:
            maskPath = UIBezierPath(roundedRect: sourceView.bounds, byRoundingCorners: .bottomLeft, cornerRadii: CGSize(width: cornorRadius, height: cornorRadius))
        case 4:
            maskPath = UIBezierPath(roundedRect: sourceView.bounds, byRoundingCorners: .bottomRight, cornerRadii: CGSize(width: cornorRadius, height: cornorRadius))
        case 5:
            maskPath = UIBezierPath(roundedRect: sourceView.bounds, byRoundingCorners: ([.topLeft, .topRight]), cornerRadii: CGSize(width: cornorRadius, height: cornorRadius))
        case 6:
            maskPath = UIBezierPath(roundedRect: sourceView.bounds, byRoundingCorners: ([.bottomLeft, .bottomRight]), cornerRadii: CGSize(width: cornorRadius, height: cornorRadius))
        case 7:
            maskPath = UIBezierPath(roundedRect: sourceView.bounds, byRoundingCorners: ([.topLeft, .bottomRight]), cornerRadii: CGSize(width: cornorRadius, height: cornorRadius))
        case 8:
            maskPath = UIBezierPath(roundedRect: sourceView.bounds, byRoundingCorners: ([.bottomLeft, .topRight]), cornerRadii: CGSize(width: cornorRadius, height: cornorRadius))
        case 9:
            maskPath = UIBezierPath(roundedRect: sourceView.bounds, byRoundingCorners: ([.topLeft, .topRight, .bottomLeft, .bottomRight]), cornerRadii: CGSize(width: cornorRadius, height: cornorRadius))
        default:
            break
        }
        let maskLayer: CAShapeLayer = CAShapeLayer()
        maskLayer.frame = sourceView.bounds
        maskLayer.path = maskPath.cgPath
        sourceView.layer.mask = maskLayer
        
    }
    
   
}
