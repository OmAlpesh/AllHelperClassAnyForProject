
//

import Foundation
import CoreLocation
import ReachabilitySwift

class Shared: NSObject, CLLocationManagerDelegate {
    let locationManager: CLLocationManager
    var doubleLat: Double
    var doubleLong: Double
    var strDeviceToken: String
    var strSessionToken: String
    var cartCount: Int
    var reachability: Reachability?
    var isReachable: Bool?
    var menuButton: ExpandingMenuButton?
    var movingMenuButton: UIButton?
    
  
    var selectedPickupDate: Date?
    var storeList: NSMutableArray
    var userDetailObj: UserDetails?
    var categoryList: NSMutableArray
    var selectedCategory: Category?
    var languageChanged: Bool = true
    var strPaymentType: PaymentType
    
    //Mark: - Init
    fileprivate override init() {
        self.strDeviceToken = "123456"
        self.strSessionToken = ""
        self.doubleLat = 0
        self.doubleLong = 0
        self.cartCount = 0
        self.locationManager = CLLocationManager()
     
        self.selectedPickupDate = nil
        self.storeList = NSMutableArray()
        self.userDetailObj = nil
        self.categoryList = NSMutableArray()
        self.selectedCategory = nil
       
        self.strPaymentType = .full
        
        super.init()
        do {
            reachability = Reachability.init()
        }
        NotificationCenter.default.addObserver(self, selector: #selector(self.reachabilityChanged(_:)), name: ReachabilityChangedNotification, object: reachability)
        do {
            try reachability!.startNotifier()
        } catch {
        }
    }
    
    class var sharedInstance: Shared {
        struct Static {
            static var instance: Shared?
            static var token: Int = 0
        }
        if Static.instance == nil {
            Static.instance = Shared()
        }
        return Static.instance!
    }
    
    //Mark: Rechability
    func reachabilityChanged(_ note: Notification) {
        
        if let reachability = note.object as? Reachability, reachability.isReachable {
            isReachable = true
            if reachability.isReachableViaWiFi {
                print("Reachable via WiFi")
            } else {
                print("Reachable via Cellular")
            }
        } else {
            CommonMethods.hideMBProgressHud()
            CommonMethods.showAlert(strMessage: "Comman_Alert_Internet", cancelButtonTitle: "OK", otherButtonTitles: nil, customAlertViewTapButtonBlock: nil, isWarning: true)
            isReachable = false
        }
    }
    
    //Mark: Current Location
    func getCurrentLocation() {
        if CLLocationManager.locationServicesEnabled() {
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyBest
            self.locationManager.requestWhenInUseAuthorization()
            locationManager.startUpdatingLocation()
        }
    }
    
    func locationManager( _ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if manager.location != nil {
            let locValue: CLLocationCoordinate2D = manager.location!.coordinate
            doubleLat = locValue.latitude
            doubleLong = locValue.longitude
            manager .stopUpdatingLocation()
        }
        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "LocationPermission"), object: nil)
    }
    
    //Mark: Expanding Menu
    fileprivate func configureExpandingMenuButton() {
        hideExpandingMenu()
        let menuButtonSize: CGSize = CGSize(width: 64.0, height: 64.0)
        menuButton = ExpandingMenuButton(frame: CGRect(origin: CGPoint.zero, size: menuButtonSize), centerImage: #imageLiteral(resourceName: "menu_icon"), centerHighlightedImage: #imageLiteral(resourceName: "menu_icon"))
        menuButton?.enabledExpandingAnimations = [.MenuItemBound, .MenuItemMoving, .MenuItemFade]
        menuButton?.enabledFoldingAnimations = [.MenuItemBound, .MenuItemMoving, .MenuItemFade]
        
        if let appDelegate: AppDelegate = UIApplication.shared.delegate as? AppDelegate {
            let windowFrame: CGRect = (appDelegate.window?.bounds)!
            menuButton?.center = CGPoint(x: windowFrame.size.width - 32.0 - 20.0, y: windowFrame.size.height - 82.0)
            
            let orderNowItem = ExpandingMenuItem(size: menuButtonSize, title: "FloatingMenu_BTN_OrderNow", image: #imageLiteral(resourceName: "order_now"), highlightedImage: #imageLiteral(resourceName: "order_now"), backgroundImage:nil, backgroundHighlightedImage:nil) { () -> Void in
                self.menuItemTapped(atIndex: .orderNow)
            }
            
            let myOrdersItem = ExpandingMenuItem(size: menuButtonSize, title: "FloatingMenu_BTN_MyOrders", image: #imageLiteral(resourceName: "my_orders"), highlightedImage: #imageLiteral(resourceName: "my_orders"), backgroundImage: nil, backgroundHighlightedImage: nil) { () -> Void in
                self.menuItemTapped(atIndex: .myOrders)
            }
            
            let settingsItem = ExpandingMenuItem(size: menuButtonSize, title: "FloatingMenu_BTN_Settings", image: #imageLiteral(resourceName: "settings"), highlightedImage: #imageLiteral(resourceName: "settings"), backgroundImage: nil, backgroundHighlightedImage: nil) { () -> Void in
                self.menuItemTapped(atIndex: .settings)
            }
            
            let logoutItem = ExpandingMenuItem(size: menuButtonSize, title: "FloatingMenu_BTN_SignOut", image: #imageLiteral(resourceName: "logout"), highlightedImage: #imageLiteral(resourceName: "logout"), backgroundImage: nil, backgroundHighlightedImage: nil) { () -> Void in
                self.menuItemTapped(atIndex: .signOut)
            }
            menuButton?.addMenuItems([logoutItem, settingsItem, myOrdersItem, orderNowItem])
            weak var weakSelf = self
            menuButton?.willPresentMenuItems = { (menu) -> Void in
                weakSelf?.menuButton?.centerButton.setImage(#imageLiteral(resourceName: "close_menu"), for: .normal)
                weakSelf?.menuButton?.centerButton.setImage(#imageLiteral(resourceName: "close_menu"), for: .highlighted)
            }
            menuButton?.willDismissMenuItems = { (menu) -> Void in
                weakSelf?.menuButton?.centerButton.setImage(#imageLiteral(resourceName: "menu_icon"), for: .normal)
                weakSelf?.menuButton?.centerButton.setImage(#imageLiteral(resourceName: "menu_icon"), for: .highlighted)
                weakSelf?.showExpandingMenu()
            }
        }
        movingMenuButton = UIButton.init(frame: CGRect(origin: CGPoint.zero, size: menuButtonSize))
        movingMenuButton?.center = (menuButton?.center)!
        movingMenuButton?.setImage(#imageLiteral(resourceName: "menu_icon"), for: .normal)
        movingMenuButton?.addTarget(self, action: #selector(expandFloatingMenu), for: .touchUpInside)
        let panGesture = UIPanGestureRecognizer(target: self, action:#selector(handlePanGesture))
        movingMenuButton?.addGestureRecognizer(panGesture)
    }
    
    @objc fileprivate func expandFloatingMenu(_ sender: UIButton) {
        weak var weakSelf = self
        UIView.animate(withDuration: 0.0, delay: 0.0, options: [], animations: {
            weakSelf?.movingMenuButton?.center = (weakSelf?.movingMenuButton?.center)!
        }, completion: { (_: Bool) in
            if let appDelegate: AppDelegate = UIApplication.shared.delegate as? AppDelegate {
                weakSelf?.movingMenuButton?.removeFromSuperview()
                appDelegate.window?.addSubview((weakSelf?.menuButton)!)
                weakSelf?.menuButton?.centerButtonTapped()
            }
        })
    }
    
    func handlePanGesture(panGesture: UIPanGestureRecognizer) {
        let appDelegate: AppDelegate = (UIApplication.shared.delegate as? AppDelegate)!
        let translation = panGesture.translation(in: appDelegate.window)
        panGesture.setTranslation(CGPoint.zero, in: appDelegate.window)
        
        let button = (panGesture.view as? UIButton)!
        let movingButtonFrame: CGRect = button.frame
        var newCenterPosition = CGPoint(x: button.center.x+translation.x, y: button.center.y+translation.y)
        if panGesture.state == UIGestureRecognizerState.began || panGesture.state == UIGestureRecognizerState.changed {
            button.center = newCenterPosition
            button.isUserInteractionEnabled = true
        } else if panGesture.state == UIGestureRecognizerState.ended {
            //Check for boundries
            if (newCenterPosition.x - (movingButtonFrame.size.width / 2)) < 0 {
                newCenterPosition.x = movingButtonFrame.size.width / 2
            }
            if (newCenterPosition.x + (movingButtonFrame.size.width / 2)) > UIScreen.main.bounds.size.width {
                newCenterPosition.x = UIScreen.main.bounds.size.width - (movingButtonFrame.size.width / 2)
            }
            if (newCenterPosition.y - (movingButtonFrame.size.height / 2)) < 0 {
                newCenterPosition.y = movingButtonFrame.size.height / 2
            }
            if (newCenterPosition.y + (movingButtonFrame.size.height / 2)) > UIScreen.main.bounds.size.height {
                newCenterPosition.y = UIScreen.main.bounds.size.height - (movingButtonFrame.size.height / 2)
            }
            
            //Move to closest edges
            if newCenterPosition.x < (UIScreen.main.bounds.size.width / 2) {
                newCenterPosition.x = movingButtonFrame.size.width / 2
            } else {
                newCenterPosition.x = UIScreen.main.bounds.size.width - (movingButtonFrame.size.width / 2)
            }
            UIView.animate(withDuration: 0.2, animations: {
                button.center = newCenterPosition
            })
        }
    }
    
    func showExpandingMenu() {
        if movingMenuButton == nil || languageChanged == true {
            languageChanged = false
            configureExpandingMenuButton()
        }
        if menuButton?.superview != nil {
            menuButton?.removeFromSuperview()
        }
        if movingMenuButton?.superview != nil {
            movingMenuButton?.removeFromSuperview()
        }
        if let appDelegate: AppDelegate = UIApplication.shared.delegate as? AppDelegate {
            appDelegate.window?.addSubview(movingMenuButton!)
        }
        updateExpandingMenuValues()
    }
    
    func hideExpandingMenu() {
        if menuButton != nil && menuButton?.superview != nil {
            menuButton?.removeFromSuperview()
        }
        if movingMenuButton != nil && movingMenuButton?.superview != nil {
            movingMenuButton?.removeFromSuperview()
        }
    }
    
    func updateExpandingMenuValues() {
        if menuButton != nil {
            if let lblName = menuButton?.bottomView.viewWithTag(101) as? UILabel {
              //  lblName.text = "FloatingMenu_LBL_Header" + " " + ((userDetailObj?.strFirstName) ?? "") + " " + ((userDetailObj?.strLastName) ?? "")
            }
            if let lblSelectedStore = menuButton?.bottomView.viewWithTag(102) as? UILabel {
               // lblSelectedStore.text = ((selectedStore?.strStoreName) ?? "") + ", " + ((selectedStore?.strStoreAddr) ?? "")
            }
        }
    }
    
    fileprivate func menuItemTapped(atIndex: SideMenuItems) {
        print("Item Index: \(atIndex)")
        
        switch atIndex {
        case .orderNow:
            //Navigate to department
            let dVC = Constant.productCatalogStoryboard.instantiateViewController(withIdentifier: "DateTimeVC")
           // Shared.sharedInstance.selectedStore = nil
            Shared.sharedInstance.hideExpandingMenu()
            if let navigationController: UINavigationController = UIApplication.shared.keyWindow!.rootViewController as? UINavigationController {
                if navigationController.topViewController?.nibName != dVC.nibName {
                    navigationController.viewControllers = [dVC]
                }
            }
        case .myOrders: //break
            //Navigate to MyOrderScren
            let mVC = Constant.checkoutStoryboard.instantiateViewController(withIdentifier: "MyOrderRootVC")
            if let navigationController: UINavigationController = UIApplication.shared.keyWindow!.rootViewController as? UINavigationController {
                if navigationController.topViewController?.nibName != mVC.nibName {
                    CommonMethods.navigateTo(mVC, inNavigationViewController: navigationController, animated: true)
                }
            }
            
        case .settings:
            //Navigate to settings
            let sVC = Constant.settingsStoryboard.instantiateViewController(withIdentifier: "SettingVC")
            if let navigationController: UINavigationController = UIApplication.shared.keyWindow!.rootViewController as? UINavigationController {
                CommonMethods.navigateTo(sVC, inNavigationViewController: navigationController, animated: true)
            }
        case .signOut: logoutWSCall()
            
        }
    }
    
    // MARK: - Other Methods
    func logoutWSCall() {
        CommonMethods.showMBProgressHud()
        let wsObj = APIManager()
        wsObj.delegate = self
        wsObj.requestForURL(strUrl: APIList.strLogoutUrl, httpMethod: "Get", parameters: nil, includeHeader: true, apiIdentifier: APIList.strLogoutUrl)
    }
    
    func clearAllCache() {
        //Empty UserDefaults
     //   UserDefaults.standard.set(Shared.sharedInstance.userDetailObj?.strPrefLanguage, forKey: "defaultlang")
        UserDefaults.standard.removeObject(forKey: "userdetail")
        UserDefaults.standard.synchronize()
        Shared.sharedInstance.strSessionToken = ""
//        Shared.sharedInstance.selectedStore = nil
//        Shared.sharedInstance.userDetailObj = nil
//        Shared.sharedInstance.cartDetailObj = nil
        Shared.sharedInstance.selectedPickupDate = nil
        Shared.sharedInstance.cartCount = 0
        DispatchQueue.main.async {
            Shared.sharedInstance.hideExpandingMenu()
            let lVC = Constant.signUpStoryboard.instantiateViewController(withIdentifier: "LoginVC")
            if let navigationController: UINavigationController = UIApplication.shared.keyWindow!.rootViewController as? UINavigationController {
                navigationController.viewControllers = [lVC]
            }
        }
    }
}

// MARK: - API Response
extension Shared: APIManagerDelegate {
    
    func apiResponseSuccess(response: NSDictionary, apiIdentifier: String) {
        CommonMethods.hideMBProgressHud()
        clearAllCache()
    }
    
    func apiResponseFail(response: NSDictionary, apiIdentifier: String) {
        print(response)
        CommonMethods.hideMBProgressHud()
        if let strMessage = response.object(forKey: "message") as? String {
            CommonMethods.showAlert(strMessage: strMessage, cancelButtonTitle: "Alert_BTN_OK", otherButtonTitles: nil, customAlertViewTapButtonBlock: nil, isWarning: true)
        }
    }
    
    func apiResponseError(error: Error?, apiIdentifier: String) {
        CommonMethods.hideMBProgressHud()
    }
}
