//
//  APIManager.swift
//  NorthGate
//
//  Created by Hardik Kothari on 07/12/16.
//  Copyright © 2016 OSS Cube. All rights reserved.
//

import UIKit
import Foundation
import MobileCoreServices

@objc protocol APIManagerDelegate {
    /// This will return response from webservice if request successfully done to server
    func apiResponseSuccess(response: NSDictionary, apiIdentifier: String)
    
    /// This will return response from webservice if request fail to server
    func apiResponseFail(response: NSDictionary, apiIdentifier: String)
    
    /// This is for Fail request or server give any error
    func apiResponseError(error: Error?, apiIdentifier: String)
}

class APIManager: NSObject {
    
    var apiIdentifier: String = ""
    var strFileName: String = "default.pdf"
    lazy var session: Foundation.URLSession = {
        let config = URLSessionConfiguration.ephemeral
        config.allowsCellularAccess = false
        let session = Foundation.URLSession(configuration: config, delegate: self, delegateQueue: OperationQueue.main)
        return session
    }()
    weak var delegate: APIManagerDelegate?
    
    private func createBodyWithParameters(parameters: NSDictionary) -> Data {
        var jsonData: Data = Data()
        do {
            jsonData = try JSONSerialization.data(withJSONObject: parameters, options: .prettyPrinted)
        } catch let error as NSError {
            print(error)
        }
        return jsonData
    }
    
    private func createMutableRequestFor(strUrl: String, httpMethod: String, parameters: NSDictionary?, includeHeader: Bool) -> NSURLRequest {
        let url = URL(string: strUrl)!
        let request = NSMutableURLRequest(url: url)
        request.httpMethod = httpMethod
        if includeHeader == true {
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            request.setValue("OAuth oauth_consumer_key=\"d4132e768b47983d44e9bb206f7d072c\",oauth_token=\"394046f62f00ef43e9c248ffb5c1ddd9\",oauth_signature_method=\"HMAC-SHA1\",oauth_timestamp=\"1485224096\",oauth_nonce=\"JPebcp\",oauth_version=\"1.0\",oauth_signature=\"7M9i5DVTnM%2FIIAdg28SO9244GvI%3D\"", forHTTPHeaderField: "Authorization")
            
            request.setValue("application/json", forHTTPHeaderField: "Accept")
            request.setValue("en", forHTTPHeaderField: "language")
            request.setValue(Shared.sharedInstance.strSessionToken, forHTTPHeaderField: "Token")
            request.setValue("iOS", forHTTPHeaderField: "source")
            request.setValue(UIDevice.current.identifierForVendor?.uuidString, forHTTPHeaderField: "device_id")
        }
        if parameters != nil && (httpMethod.lowercased() == "post" || httpMethod.lowercased() == "put") {
            request.httpBody = createBodyWithParameters(parameters: parameters!)
        } else if parameters != nil && (httpMethod.lowercased() == "get" || httpMethod.lowercased() == "delete") {
            let queryString = parameters?.stringFromHttpParameters()
            request.url = URL(string: strUrl + "?" + queryString!)!
        }
        return request
    }
    
    func requestForURL(strUrl: String, httpMethod: String, parameters: NSDictionary?, includeHeader: Bool, apiIdentifier: String) {
        if Shared.sharedInstance.isReachable! {
            self.apiIdentifier = apiIdentifier
            let request = createMutableRequestFor(strUrl: APIList.strServerUrl + strUrl, httpMethod: httpMethod, parameters: parameters, includeHeader: includeHeader)
            
            let session = URLSession.shared
            session.configuration.timeoutIntervalForRequest = 30.0
            session.configuration.timeoutIntervalForResource = 60.0
            let task = session.dataTask(with: request as URLRequest) { data, response, error in
                if error != nil {
                    if self.delegate != nil {
                        self.delegate?.apiResponseError(error: error!, apiIdentifier: self.apiIdentifier)
                    }
                } else {
                    do {
                        if let responseDictionary = try JSONSerialization.jsonObject(with: data!, options: []) as? NSDictionary {
                            if self.checkForValidResponse(responseDict: responseDictionary) {
                                if (responseDictionary["status"] as? String)?.lowercased() == "success" {
                                    if self.delegate != nil {
                                        self.delegate?.apiResponseSuccess(response: responseDictionary, apiIdentifier: self.apiIdentifier)
                                    }
                                } else {
                                    if self.delegate != nil {
                                        self.delegate?.apiResponseFail(response: responseDictionary, apiIdentifier: self.apiIdentifier)
                                    }
                                }
                            } else {
                                self.clearAllCache(responseDict: responseDictionary)
                            }
                        }
                    } catch {
                        let responseString = String(data: data!, encoding: String.Encoding(rawValue: String.Encoding.utf8.rawValue))
                        print("responseString = \(responseString ?? "")")
                        if self.delegate != nil {
                            self.delegate?.apiResponseError(error: nil, apiIdentifier: self.apiIdentifier)
                        }
                    }
                }
            }
            task.resume()
        } else {
            CommonMethods.hideMBProgressHud()
            CommonMethods.showAlert(strMessage: "Comman_Alert_Internet".localizedText(), cancelButtonTitle: "OK", otherButtonTitles: nil, customAlertViewTapButtonBlock: nil, isWarning: true)
        }
    }
    
    func requestForFileDownload(strUrl: String, apiIdentifier: String, fileName: String) {
        self.apiIdentifier = apiIdentifier
        let url = URL(string: strUrl)!
        strFileName = fileName
        let req = URLRequest(url:url)
        let task = session.downloadTask(with: req)
        task.resume()
    }
    
    // MARK: - Other Methods
    func checkForValidResponse(responseDict: NSDictionary) -> Bool {
        if let status = responseDict.object(forKey: "code") as? Int, status == 400 {
            return false
        }
        return true
    }
    
    func clearAllCache(responseDict: NSDictionary) {
        //Empty UserDefaults
        UserDefaults.standard.removeObject(forKey: "userdetail")
        UserDefaults.standard.synchronize()
        Shared.sharedInstance.strSessionToken = ""
        Shared.sharedInstance.selectedStore = nil
        Shared.sharedInstance.userDetailObj = nil
        Shared.sharedInstance.cartDetailObj = nil
        Shared.sharedInstance.selectedPickupDate = nil
        Shared.sharedInstance.cartCount = 0
        let strMessage = responseDict.object(forKey: "message") as? String
        DispatchQueue.main.async {
        CommonMethods.hideMBProgressHud()
        CommonMethods.showAlert(strMessage: strMessage ?? "Token Expired", cancelButtonTitle: "OK", otherButtonTitles: nil, customAlertViewTapButtonBlock: { _ in
            self.navigateToLogin()
        }, isWarning: true)
        }
    }
    
    func navigateToLogin() {
        DispatchQueue.main.async {
            Shared.sharedInstance.hideExpandingMenu()
            let lVC = Constant.signUpStoryboard.instantiateViewController(withIdentifier: "LoginVC")
            if let navigationController: UINavigationController = UIApplication.shared.keyWindow!.rootViewController as? UINavigationController {
                navigationController.viewControllers = [lVC]
            }
        }
    }
    
}

extension APIManager: URLSessionDownloadDelegate {
    // MARK: - URLSession Download Delegate
    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didWriteData bytesWritten: Int64, totalBytesWritten writ: Int64, totalBytesExpectedToWrite exp: Int64) {
        print("downloaded \(100*writ/exp)")
        DispatchQueue.main.async(execute: {
            CommonMethods.hud.progress = Float(100*writ/exp)
            return
        })
    }
    
    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didResumeAtOffset fileOffset: Int64, expectedTotalBytes: Int64) {
    }
    
    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        if error != nil {
            print("completed: error: \(error!)")
            if self.delegate != nil {
                self.delegate?.apiResponseError(error: error!, apiIdentifier: self.apiIdentifier)
            }
        }
    }
    
    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {
        print(location)
        // Create destination URL
        let documentsUrl: URL =  FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first as URL!
        let destinationFileUrl = documentsUrl.appendingPathComponent(strFileName)
        do {
            try FileManager.default.copyItem(at: location, to: destinationFileUrl)
        } catch (let writeError) {
            print("Error creating a file \(destinationFileUrl) : \(writeError)")
        }
        if self.delegate != nil {
            let responseDict = NSMutableDictionary()
            responseDict.setValue(200, forKey: "code")
            responseDict.setValue(strFileName, forKey: "filepath")
            self.delegate?.apiResponseSuccess(response: responseDict, apiIdentifier: self.apiIdentifier)
        }
        
    }
}
