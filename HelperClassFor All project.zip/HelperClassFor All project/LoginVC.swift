//
//  LoginVC.swift
//  NorthGate
//
//  Created by Siddhant jain on 08/12/16.
//  Copyright © 2016 OSS Cube. All rights reserved.
//

import UIKit
import FBSDKLoginKit
import GoogleSignIn
import TwitterKit
import BSKeyboardControls

class LoginVC: UIViewController {
    
    // MARK: - Outlets
    @IBOutlet weak var txtUserName: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    @IBOutlet weak var btnForgotPassword: UIButton!
    @IBOutlet weak var btnSignIn: UIButton!
    @IBOutlet weak var lblDontHaveAccount: UILabel!
    @IBOutlet weak var btnSignUp: UIButton!
    @IBOutlet weak var lblOR: UILabel!
    @IBOutlet weak var btnGoogle: UIButton!
    @IBOutlet weak var cnstLogoBottomSpace: NSLayoutConstraint!
    @IBOutlet weak var cnstEmailBottomSpace: NSLayoutConstraint!
    @IBOutlet weak var cnstSignInBottomSpace: NSLayoutConstraint!
    @IBOutlet weak var cnstDontHaveACCBottomSpace: NSLayoutConstraint!
    @IBOutlet weak var cnstORBottomSpace: NSLayoutConstraint!
    @IBOutlet weak var cnstTWBottomSpace: NSLayoutConstraint!
    @IBOutlet weak var btnFb: UIButton!
    
    // MARK: - Variables
    var keyboardControls: BSKeyboardControls?
    var strLoginPlatform: String = ""
    var strSocialId: String = ""
    var strFirstName: String = ""
    var strLastName: String = ""
    var strEmailID: String = ""
    lazy var fields: [UITextField] = {
        
        return {
            [self.txtUserName, self.txtPassword]
        }
        }()()
    // MARK: - User Actions
    @IBAction func forgotPasswordTapped(_ sender: Any) {
        if let forgotPasswordVC = self.storyboard?.instantiateViewController(withIdentifier: "ForgotPasswordVC") {
            CommonMethods.navigateTo(forgotPasswordVC, inNavigationViewController: self.navigationController!, animated: true)
        }
    }
    
    @IBAction func signInTapped(_ sender: Any) {
        //Resign TextFields
        fields.resignAllTextfields(arrTxtFields: fields)
        if validation() {
            loginWSCall(emailId: txtUserName.text!, password: txtPassword.text!, type: "portal", tId: "")
        }
    }
    
    @IBAction func signUpTapped(_ sender: Any) {
        if let signUpVC = self.storyboard?.instantiateViewController(withIdentifier: "SignUpVC") {
            CommonMethods.navigateTo(signUpVC, inNavigationViewController: self.navigationController!, animated: true)
        }
    }
    
    @IBAction func fbTapped(_ sender: Any) {
        btnFb.isEnabled = false
        let fbLoginManager: FBSDKLoginManager = FBSDKLoginManager()
        fbLoginManager.logOut()
        fbLoginManager.logIn(withReadPermissions: ["email"], from : self, handler: { (result, error) -> Void in
            
            if error == nil {
                
                if let fbloginresult: FBSDKLoginManagerLoginResult = result {
                   
                    if fbloginresult.grantedPermissions != nil {
                            self.getFBUserData()
                            CommonMethods.hideMBProgressHud()
                    } else {
                        self.btnFb.isEnabled = true
                        CommonMethods.hideMBProgressHud()
                    }
                }
            } else {
                self.btnFb.isEnabled = true
                CommonMethods.hideMBProgressHud()
            }
        })
    }
    
    @IBAction func twitterTapped(_ sender: UIButton) {
        //Twitter.sharedInstance().sessionStore.logOutUserID((sharedObj?.strTWTRID)!)
        weak var weakSelf = self
        sender.isEnabled = false
        Twitter.sharedInstance().logIn { (session, _) in
            sender.isEnabled = true
            if let unwrappedSession = session {
                Twitter.sharedInstance().sessionStore.logOutUserID(unwrappedSession.userID)
                weakSelf?.strSocialId = unwrappedSession.userID
                weakSelf?.strLoginPlatform = "twitter"
                weakSelf?.loginWSCall(emailId: "", password: "", type: "twitter", tId: unwrappedSession.userID)
                
            }
        }
    }
    
    @IBAction func googlePlusTapped(_ sender: Any) {
        btnGoogle.isEnabled = false
        GIDSignIn.sharedInstance().signIn()
    }
    
    // MARK: - Life Cycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        GIDSignIn.sharedInstance().uiDelegate = self
        GIDSignIn.sharedInstance().delegate = self
        self.navigationController?.interactivePopGestureRecognizer?.isEnabled = false
        //        txtUserName.text = "siddhant.jain@credencys.com"
        //        txtPassword.text = "vfBqEsMm"
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        //Navigation bar
        self.navigationController?.isNavigationBarHidden = true
        //Setup Interface
        setupUI()
        localizeUI()
        // check if reg success email exist then fill that
        if let regEmailString = UserDefaults.standard.value(forKey: "regEmail") as? String {
            txtUserName.text = regEmailString
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.view.endEditing(true)
        self.navigationItem.title = "Back"
    }
    
    // MARK: SetupUI
    func setupUI() {
        //Keyboard toolbar
        if Constant.isiPhone5 {
            cnstLogoBottomSpace.constant = 16
            cnstEmailBottomSpace.constant = 16
            cnstSignInBottomSpace.constant = 16
            cnstDontHaveACCBottomSpace.constant = 16
            cnstORBottomSpace.constant = 16
            cnstTWBottomSpace.constant = 16
        }
        keyboardControls = BSKeyboardControls.init(fields: fields as? [FloatLabelTextField])
        keyboardControls?.delegate = self
    }
    
    func localizeUI() {
        
        txtUserName.placeholder = "Login_TXT_Email".localizedText()
        txtPassword.placeholder = "Login_TXT_Password".localizedText()
        lblDontHaveAccount.text = "Login_LBL_DontHaveAnAccount".localizedText()
        lblOR.text = "Login_LBL_OR".localizedText()
        btnForgotPassword.setTitle("Login_BTN_ForgotPassword".localizedText(), for: .normal)
        btnForgotPassword.setTitle("Login_BTN_ForgotPassword".localizedText(), for: .highlighted)
        btnForgotPassword.setTitle("Login_BTN_ForgotPassword".localizedText(), for: .selected)
        btnSignIn.setTitle("Login_BTN_SignIn".localizedText(), for: .normal)
        btnSignIn.setTitle("Login_BTN_SignIn".localizedText(), for: .highlighted)
        btnSignIn.setTitle("Login_BTN_SignIn".localizedText(), for: .selected)
        btnSignUp.setTitle("Login_BTN_SignUp".localizedText(), for: .normal)
        btnSignUp.setTitle("Login_BTN_SignUp".localizedText(), for: .highlighted)
        btnSignUp.setTitle("Login_BTN_SignUp".localizedText(), for: .selected)
    }
    
    // MARK: - User Methods
    func getFBUserData() {
        if FBSDKAccessToken.current() != nil {
            FBSDKGraphRequest(graphPath: "me", parameters: ["fields": "id, name, first_name, last_name, picture.type(large), email"]).start(completionHandler: { (_, result, error) in
                self.btnFb.isEnabled = true
                if error == nil {
                    self.strLoginPlatform = "facebook"
                    if let strId = (result as? NSDictionary)?.object(forKey: "id") as? String {
                        self.strSocialId = strId
                    }
                    if let strName = (result as? NSDictionary)?.object(forKey: "first_name") as? String {
                        self.strFirstName = strName
                    }
                    
                    if let strName = (result as? NSDictionary)?.object(forKey: "last_name") as? String {
                        self.strLastName = strName
                    }
                    
                    if let strEmail  = (result as? NSDictionary)?.object(forKey: "email") as?String {
                        self.strEmailID = strEmail
                    }
                    
                    self.loginWSCall(emailId: self.strEmailID, password: "", type: self.strLoginPlatform, tId: self.strSocialId)
                } else {
                    self.btnFb.isEnabled = true
                    CommonMethods.hideMBProgressHud()
                }
            })
        }
    }
    
    // MARK: - Helper Method
    func validation() -> Bool {
        
        txtUserName.text = txtUserName.text?.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
        txtPassword.text = txtPassword.text?.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
        
        if Shared.sharedInstance.isReachable == false {
            CommonMethods.showAlert(strMessage: "Comman_Alert_Internet".localizedText(), cancelButtonTitle: "Alert_BTN_OK".localizedText(), otherButtonTitles: nil, customAlertViewTapButtonBlock: nil, isWarning: true)
            return false
        } else if (txtUserName.text?.isEmpty)! {
            CommonMethods.showAlert(strMessage: "Val_Email_Empty".localizedText(), cancelButtonTitle: "Alert_BTN_OK".localizedText(), otherButtonTitles: nil, customAlertViewTapButtonBlock: nil, isWarning: true)
            return false
        } else if !CommonMethods.emailAdrressValidation(strEmail: txtUserName.text!) {
            CommonMethods.showAlert(strMessage: "Val_Email_Valid".localizedText(), cancelButtonTitle: "Alert_BTN_OK".localizedText(), otherButtonTitles: nil, customAlertViewTapButtonBlock: nil, isWarning: true)
            return false
        } else  if (txtPassword.text?.isEmpty)! {
            CommonMethods.showAlert(strMessage: "Val_Pass_Empty".localizedText(), cancelButtonTitle: "Alert_BTN_OK".localizedText(), otherButtonTitles: nil, customAlertViewTapButtonBlock: nil, isWarning: true)
            return false
        } else if (txtPassword.text?.characters.count)! < 6 {
            CommonMethods.showAlert(strMessage: "Val_Pass_Valid".localizedText(), cancelButtonTitle: "Alert_BTN_OK".localizedText(), otherButtonTitles: nil, customAlertViewTapButtonBlock: nil, isWarning: true)
            return false
        } else {
            return true
        }
    }
    
    func navigateToSignup() {
        let sVC = self.storyboard?.instantiateViewController(withIdentifier: "SignUpVC") as? SignUpVC
        sVC?.strFirstName = strFirstName
        sVC?.strLastName = strLastName
        sVC?.strLoginPlatform = strLoginPlatform
        sVC?.strEmailID = strEmailID
        sVC?.strSocialId = strSocialId
        CommonMethods.navigateTo(sVC!, inNavigationViewController: self.navigationController!, animated: true)
    }
    
    // MARK: - WS Call
    func loginWSCall(emailId stremail: String, password strPass: String, type strType: String, tId strTid: String) {
        CommonMethods.showMBProgressHud()
        let wsObj = APIManager()
        wsObj.delegate = self
        let para = ["email": stremail, "password": strPass.sha256Encryption()!, "type_id": strTid, "type": strType, "notification_token": Shared.sharedInstance.strDeviceToken]
        wsObj.requestForURL(strUrl: APIList.strLoginUrl, httpMethod: "Post", parameters: para as NSDictionary?, includeHeader: true, apiIdentifier: "login")
    }
}

// MARK: - Social Login Methods
extension LoginVC: GIDSignInUIDelegate {
    func sign(_ signIn: GIDSignIn!, present viewController: UIViewController!) {
        
        self.present(viewController, animated: true, completion: nil)
    }
    
    func sign(_ signIn: GIDSignIn!, dismiss viewController: UIViewController!) {
        btnGoogle.isEnabled = true
        self.dismiss(animated: true, completion: nil)
    }
}

extension LoginVC: GIDSignInDelegate {
    func sign(_ signIn: GIDSignIn!, didSignInFor user: GIDGoogleUser!, withError error: Error!) {
        btnGoogle.isEnabled = true
        if error == nil {
            print("\(user.description)")
            strFirstName = user.profile.givenName
            strLastName = user.profile.familyName
            strEmailID = user.profile.email
            strSocialId = user.userID
            strLoginPlatform = "google+"
            loginWSCall(emailId: user.profile.email, password: "", type: "google+", tId: user.userID)
        } else {
            print("\(error.localizedDescription)")
        }
    }
    
    func sign(_ signIn: GIDSignIn!, didDisconnectWith user: GIDGoogleUser!, withError error: Error!) {
        btnGoogle.isEnabled = true
    }
}

// MARK: - Textfield Methods
extension LoginVC: UITextFieldDelegate {
    
    // MARK: UITextfield delegate
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        return true
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        keyboardControls?.activeField = textField
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
}

// MARK: - Keyboard Delegate
extension LoginVC: BSKeyboardControlsDelegate {
    func keyboardControlsDonePressed(_ keyboardControls: BSKeyboardControls) {
        self.view.endEditing(true)
    }
}

// MARK: - API Methods
extension LoginVC: APIManagerDelegate {
    func apiResponseSuccess(response: NSDictionary, apiIdentifier: String) {
        CommonMethods.hideMBProgressHud()
        if apiIdentifier == "login" {
            let userObj = UserDetails.init(fromDictionary: response)
            Shared.sharedInstance.userDetailObj = userObj
            Shared.sharedInstance.strSessionToken = userObj.strToken! as String
            if let strCartItem = userObj.strCartItem, let count = Int(strCartItem) {
                Shared.sharedInstance.cartCount = count
            } else {
                Shared.sharedInstance.cartCount = 0
            }
            //Save To Defaults
            let userDefaults = UserDefaults.standard
            let encodedData: Data = NSKeyedArchiver.archivedData(withRootObject: userObj)
            userDefaults.set(encodedData, forKey: "userdetail")
            userDefaults.synchronize()
            UserDefaults.standard.setValue(txtUserName.text, forKey: "regEmail")
            fields.emptyAllTextfields()
            if let dateTimeVC = Constant.productCatalogStoryboard.instantiateViewController(withIdentifier: "DateTimeVC") as? DateTimeVC {
                CommonMethods.navigateTo(dateTimeVC, inNavigationViewController: self.navigationController!, animated: true)
            }
        }
    }
    
    func apiResponseFail(response: NSDictionary, apiIdentifier: String) {
        CommonMethods.hideMBProgressHud()
        print(response)
        if apiIdentifier == "login" {
            guard let status = response.object(forKey: "code") as? Int else {
                DispatchQueue.main.async(execute: {
                    CommonMethods.showAlert(strMessage: "Comman_Alert_ResponseNil".localizedText(), cancelButtonTitle: "Alert_BTN_OK".localizedText(), otherButtonTitles: nil, customAlertViewTapButtonBlock: nil, isWarning: true)
                })
                return
            }
            switch status {
            case 15004, 15001, 300:  navigateToSignup()
                break
            case 500: let strMessage = response.object(forKey: "message") as? String
            DispatchQueue.main.async(execute: {
                CommonMethods.showAlert(strMessage: strMessage ?? "Something went wrong", cancelButtonTitle: "Alert_BTN_OK".localizedText(), otherButtonTitles: nil, customAlertViewTapButtonBlock: nil, isWarning: true)
            })
                break
            default: break
            }
        }
    }
    
    func apiResponseError(error: Error?, apiIdentifier: String) {
        CommonMethods.hideMBProgressHud()
        if apiIdentifier == "login" {
            
        }
    }
}
