//
//  CustomAlertVC.swift
//  NorthGate
//
//  Created by Hardik Kothari on 15/12/16.
//  Copyright © 2016 OSS Cube. All rights reserved.
//

import UIKit

class CustomAlertVC: UIViewController {
    
    // MARK: Outlets
    @IBOutlet weak var imgAlertIcon: UIImageView!
    @IBOutlet weak var lblMessage: UILabel!
    @IBOutlet weak var vwSingleButton: UIView!
    @IBOutlet weak var vwTwoButtons: UIView!
    @IBOutlet weak var btnOK: UIButton!
    @IBOutlet weak var btnCancel: UIButton!
    @IBOutlet weak var btnOther: UIButton!
    @IBOutlet weak var constraingIconTitleSpace: NSLayoutConstraint!
    @IBOutlet weak var constraintImageWidth: NSLayoutConstraint!
    
    // MARK: Variables
    typealias CustomAlertViewTapButtonBlock = (Int) -> Void
    var message: String = ""
    var alertIcon: UIImage?
    var cancelButtonTitle: String = ""
    var otherButtonTitles: [String]?
    var buttonDidTappedBlock: CustomAlertViewTapButtonBlock?
    
    // MARK: User Actions
    @IBAction func alertButtonTapped(_ sender: UIButton) {
        if buttonDidTappedBlock != nil {
            buttonDidTappedBlock!(sender.tag)
        }
        dismiss(animated: true, completion: nil)
    }
    
    // MARK: Life Cycle Methods
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
    }
    
    convenience init(WithMessage message: String, alertIcon: UIImage?, cancelButtonTitle: String, otherButtonTitles: [String]?) {
        self.init(nibName: "CustomAlertVC", bundle: nil)
        self.modalPresentationStyle = .overFullScreen
        
        self.message = message
        self.alertIcon = alertIcon
        self.cancelButtonTitle = cancelButtonTitle
        self.otherButtonTitles = otherButtonTitles
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func setup() {
        lblMessage.text = message
        imgAlertIcon.image = alertIcon
        btnCancel.layer.borderWidth = 1.0
        btnCancel.layer.borderColor = UIColor(red: 196/255.0, green: 18/255.0, blue: 48/255.0, alpha: 1.0).cgColor
        if alertIcon == nil {
            constraingIconTitleSpace.constant = 0.0
            constraintImageWidth.constant = 0.0
        } else {
            constraingIconTitleSpace.constant = 10.0
            constraintImageWidth.constant = 30.0
        }
        
        if otherButtonTitles == nil {
            vwTwoButtons.isHidden = true
            vwSingleButton.isHidden = false
            
            btnOK.setTitle(cancelButtonTitle, for: .normal)
            btnOK.setTitle(cancelButtonTitle, for: .highlighted)
            btnOK.setTitle(cancelButtonTitle, for: .selected)
        } else {
            vwTwoButtons.isHidden = false
            vwSingleButton.isHidden = true
            
            btnCancel.setTitle(cancelButtonTitle, for: .normal)
            btnCancel.setTitle(cancelButtonTitle, for: .highlighted)
            btnCancel.setTitle(cancelButtonTitle, for: .selected)
            
            btnOther.setTitle(otherButtonTitles?[0], for: .normal)
            btnOther.setTitle(otherButtonTitles?[0], for: .highlighted)
            btnOther.setTitle(otherButtonTitles?[0], for: .selected)
        }
    }
}
