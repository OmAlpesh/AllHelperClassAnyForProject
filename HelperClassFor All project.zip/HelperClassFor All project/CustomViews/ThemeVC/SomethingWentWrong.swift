//
//  SomethingWentWrong.swift
//  NorthGate
//
//  Created by jignesh on 15/03/17.
//  Copyright © 2017 OSS Cube. All rights reserved.
//

import UIKit

class SomethingWentWrong: UIView {

    @IBOutlet weak var cnstImgTopSpace: NSLayoutConstraint!
    @IBOutlet weak var cnstImgBottomSpace: NSLayoutConstraint!
    @IBOutlet weak var lblTop: UILabel!
    @IBOutlet weak var lblBottom: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        if Constant.isiPhone5 {
            cnstImgTopSpace.constant = 32.0
            cnstImgBottomSpace.constant = 32.0
        }
        lblTop.text = "Something_Went_Wrong_top_lbl".localizedText()
        lblBottom.text = "Something_Went_Wrong_bottom_lbl".localizedText()
    }
}
