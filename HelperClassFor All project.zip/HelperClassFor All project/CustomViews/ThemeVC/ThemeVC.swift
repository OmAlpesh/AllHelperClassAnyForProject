//
//  ThemeVC.swift
//  NorthGate
//
//  Created by Siddhant jain on 09/12/16.
//  Copyright © 2016 OSS Cube. All rights reserved.
//

import UIKit

class ThemeVC: UIViewController {
    
    // MARK: - Variables
    let vwBottomMenu: UIView = (Bundle.main.loadNibNamed("BottomMenu", owner: self, options: nil)?.first as? UIView)!
    let vwSomethingWrong: UIView = (Bundle.main.loadNibNamed("SomethingWentWrong", owner: self, options: nil)?.first as? UIView)!
    
    // MARK: - User Actions
    func storeTapped() {
        let storeDetailsVC = Constant.productCatalogStoryboard.instantiateViewController(withIdentifier: "StoreDetailsVC") as? StoreDetailsVC
        storeDetailsVC?.delegate = self
        storeDetailsVC?.modalPresentationStyle = .custom
        storeDetailsVC?.modalTransitionStyle = .crossDissolve
        present(storeDetailsVC!, animated: true, completion: nil)
    }
    
    func cartTapped() {
        if let checkoutVC = Constant.checkoutStoryboard.instantiateViewController(withIdentifier: "CheckoutVC") as? CheckoutVC {
            CommonMethods.navigateTo(checkoutVC, inNavigationViewController: self.navigationController!, animated: true)
        }
    }
    
    // MARK: - Life Cycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    // MARK: Methods
    func addBackgroundImage() {
        let imgViewBackground = UIImageView.init(frame: CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: self.view.frame.size.height))
        imgViewBackground.image = #imageLiteral(resourceName: "bgregister")
        self.view.insertSubview(imgViewBackground, at: 0)
    }
    
    func addBottomMenu() {
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 0.1) {
            let bottomMenuFrame: CGRect = CGRect(x: 0.0, y: self.view.frame.size.height - 44.0, width: UIScreen.main.bounds.size.width, height: 44.0)
            self.vwBottomMenu.frame = bottomMenuFrame
            self.vwBottomMenu.layoutSubviews()
            self.view.addSubview(self.vwBottomMenu)
            self.view.bringSubview(toFront: self.vwBottomMenu)
            //add target
            if let btnStore = self.vwBottomMenu.viewWithTag(10) as? UIButton {
                btnStore.addTarget(self, action: #selector(self.storeTapped), for: UIControlEvents.touchUpInside)
            }
            if let btnCart = self.vwBottomMenu.viewWithTag(20) as? UIButton {
                btnCart.addTarget(self, action: #selector(self.cartTapped), for: UIControlEvents.touchUpInside)
            }
            self.showBottomMenuDetails()
        }
    }
    
    func showSomethingWentWrong() {
        if vwSomethingWrong.superview != nil {
            vwSomethingWrong.removeFromSuperview()
        }
        let viewFrame: CGRect = CGRect(x: 0.0, y: 0, width: UIScreen.main.bounds.size.width, height: self.view.frame.size.height)
        self.vwSomethingWrong.frame = viewFrame
        self.vwSomethingWrong.layoutSubviews()
        self.view.addSubview(self.vwSomethingWrong)
        self.view.bringSubview(toFront: self.vwSomethingWrong)
    }
    
    func hideSomethingWentWrong() {
        if vwSomethingWrong.superview != nil {
            vwSomethingWrong.removeFromSuperview()
        }
    }
    // MARK: Assign/Update Values
    func showBottomMenuDetails() {
        let lblStoreName: UILabel = (vwBottomMenu.viewWithTag(1) as? UILabel)!
        if let selectedStore = Shared.sharedInstance.selectedStore {
            lblStoreName.text = selectedStore.strStoreName! + ", " + selectedStore.strStoreAddr!
        } else {
            lblStoreName.text = "-"
        }
        let lblPickupTime: UILabel = (vwBottomMenu.viewWithTag(2) as? UILabel)!
        if Shared.sharedInstance.cartDetailObj != nil {
            let pickupDate = Shared.sharedInstance.cartDetailObj?.strPickupDate?.convertDate(fromFormat: "MM/dd/yyyy", toFormat: "MMM dd")
            lblPickupTime.text = "\(pickupDate!) | \((Shared.sharedInstance.cartDetailObj?.strPickupTime)!)"
        } else {
            if let pickUpDate = Shared.sharedInstance.selectedPickupDate {
                lblPickupTime.text = pickUpDate.stringFor(format: "MMM dd | hh:mm a")
            } else {
                lblPickupTime.text = "-"
            }
        }
    }
    
    func navigateToDepartment() {
        let dVC = Constant.productCatalogStoryboard.instantiateViewController(withIdentifier: "DepartmentVC")
        if let navigationController: UINavigationController = UIApplication.shared.keyWindow!.rootViewController as? UINavigationController {
            navigationController.viewControllers = [dVC]
        }
    }
    
    func setMarqueeTitle(title: String) {
        let marqueeLabel = MarqueeLabel(frame: CGRect.init(x: 0, y: 0, width: 320, height: 25), duration: 7.0, fadeLength: 20.0)
        marqueeLabel.font = UIFont(name: "PlayfairDisplay-Italic", size: 18.0)
        marqueeLabel.textColor = UIColor.white
        marqueeLabel.trailingBuffer = 30.0
        marqueeLabel.text = title
        marqueeLabel.textAlignment = .center
        self.navigationItem.titleView = marqueeLabel
    }
}

// MARK: StoreDetailsDelegate
extension ThemeVC: StoreDetailsDelegate {
    func didOptToChangeStore() {
        let sVC = Constant.productCatalogStoryboard.instantiateViewController(withIdentifier: "StoreListVC") as? StoreListVC
        let navController = UINavigationController.init(rootViewController: sVC!)
        sVC?.isPresentedFromBottom = true
        present(navController, animated: true, completion: nil)
    }
}
